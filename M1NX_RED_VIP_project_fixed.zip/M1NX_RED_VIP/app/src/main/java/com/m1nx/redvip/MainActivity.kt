package com.m1nx.redvip

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFFF263D)
private val Bg = Color(0xFF0B0B0E)
private val CardBg = Color(0xFF1A1A21)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("red_vip", MODE_PRIVATE)

        setContent {
            var general by remember { mutableFloatStateOf(prefs.getFloat("general", 150f)) }
            var redDot by remember { mutableFloatStateOf(prefs.getFloat("red_dot", 140f)) }
            var scope2x by remember { mutableFloatStateOf(prefs.getFloat("scope2x", 130f)) }
            var scope4x by remember { mutableFloatStateOf(prefs.getFloat("scope4x", 120f)) }
            var sniper by remember { mutableFloatStateOf(prefs.getFloat("sniper", 100f)) }
            var freeLook by remember { mutableFloatStateOf(prefs.getFloat("free_look", 100f)) }
            var dpi by remember { mutableFloatStateOf(prefs.getFloat("dpi", 420f)) }
            var saved by remember { mutableStateOf(false) }
            var note by remember { mutableStateOf("اختار القيم وجربها تدريجياً داخل اللعبة.") }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Bg, surface = CardBg
            )) {
                Column(
                    Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("M1NX RED VIP", color = Red, fontSize = 28.sp)
                    Text("HONOR Magic5 Lite 5G • Free Fire settings helper", color = Color.LightGray)
                    Text("القيم كتتحفظ هنا فقط؛ دخلها يدوياً فإعدادات اللعبة.", color = Color.LightGray, fontSize = 13.sp)
                    Text("SENSITIVITY", color = Red, fontSize = 16.sp)
                    SliderCard("General", general, 0f..200f) { general = it; saved = false }
                    SliderCard("Red Dot", redDot, 0f..200f) { redDot = it; saved = false }
                    SliderCard("2x Scope", scope2x, 0f..200f) { scope2x = it; saved = false }
                    SliderCard("4x Scope", scope4x, 0f..200f) { scope4x = it; saved = false }
                    SliderCard("Sniper", sniper, 0f..200f) { sniper = it; saved = false }
                    SliderCard("Free Look", freeLook, 0f..200f) { freeLook = it; saved = false }
                    Text("DPI (تسجيل القيمة فقط)", color = Red, fontSize = 16.sp)
                    SliderCard("DPI", dpi, 200f..800f) { dpi = it; saved = false }
                    Text("FPS & PING", color = Red, fontSize = 16.sp)
                    Text(
                        "هاد التطبيق ما كيقدرش يفرض 120 FPS أو يثبت Ping. اختار أعلى FPS متاح من إعدادات اللعبة، واستعمل Wi‑Fi مستقر أو شبكة قوية.",
                        color = Color.LightGray
                    )
                    Button(
                        onClick = {
                            prefs.edit().putFloat("general", general).putFloat("red_dot", redDot)
                                .putFloat("scope2x", scope2x).putFloat("scope4x", scope4x)
                                .putFloat("sniper", sniper).putFloat("free_look", freeLook)
                                .putFloat("dpi", dpi).apply()
                            saved = true
                            note = "تحفظات القيم داخل التطبيق."
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)
                    ) { Text("حفظ الإعدادات") }
                    Button(
                        onClick = {
                            if (Settings.canDrawOverlays(this@MainActivity)) {
                                startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                                note = "تشعلات اللوحة العائمة. تقدر تسدها من الزر X."
                            } else {
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")))
                                note = "فعّل السماح بالظهور فوق التطبيقات، ومن بعد رجع للتطبيق واضغط مرة أخرى."
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = CardBg)
                    ) { Text("تشغيل اللوحة العائمة") }
                    if (saved) Text("✓ $note", color = Color(0xFF71E59A))
                    else Text(note, color = Color.LightGray)
                    Text(
                        "ملاحظة: الحساسية وDPI هنا كيتحفظو داخل التطبيق فقط. DPI ما كيتبدلش أوتوماتيكياً، والتطبيق ما كيتحكمش فـ Free Fire.",
                        color = Color.Gray, fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SliderCard(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("$label: ${value.toInt()}", color = Color.White)
            Slider(value = value, onValueChange = onChange, valueRange = range,
                colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red))
        }
    }
}
