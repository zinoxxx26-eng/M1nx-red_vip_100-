package com.m1nx.redvip

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.graphics.Color as AndroidColor

class FloatingPanelService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(AndroidColor.rgb(25, 25, 31))
        }
        val title = Button(this).apply {
            text = "M1NX RED VIP  •  X"
            setTextColor(AndroidColor.WHITE)
            setBackgroundColor(AndroidColor.rgb(255, 38, 61))
            setOnClickListener { stopSelf() }
        }
        val info = Button(this).apply {
            text = "الإعدادات محفوظة داخل التطبيق"
            setTextColor(AndroidColor.WHITE)
            setBackgroundColor(AndroidColor.rgb(45, 45, 52))
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch != null) startActivity(launch)
            }
        }
        layout.addView(title)
        layout.addView(info)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 160 }

        windowManager?.addView(layout, params)
        panel = layout
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { view -> try { windowManager?.removeView(view) } catch (_: Exception) {} }
        panel = null
        windowManager = null
        super.onDestroy()
    }
}
